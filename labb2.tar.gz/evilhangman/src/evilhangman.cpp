#include <iostream>
#include <string>
using namespace std;

const string ALPHABET  = "abcdefghijklmnopqrstuvwxyz";

int main() {
    cout << "Welcome to Hangman." << endl;

    // TODO: Finish the program!

    return 0;
}
